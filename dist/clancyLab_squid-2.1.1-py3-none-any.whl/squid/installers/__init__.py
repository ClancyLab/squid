from squid.installers.install_nlopt import run_install as nlopt_installer
from squid.installers.install_lammps import run_install as lammps_installer
from squid.installers.install_openmpi import run_install as openmpi_installer
from squid.installers.install_packmol import run_install as packmol_installer
